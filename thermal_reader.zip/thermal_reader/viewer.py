"""
viewer.py
---------

Affichage interactif de l'image thermique : cliquez sur un pixel pour
afficher sa température réelle dans le titre du graphique et la console.
"""

from __future__ import annotations

import matplotlib.pyplot as plt

from .colorize import colorize_temperature
from .converter import ThermalImage


def show_interactive(thermal_image: ThermalImage, cmap_name: str = "inferno") -> None:
    """Ouvre une fenêtre matplotlib interactive.

    Clic gauche sur un pixel -> affiche sa température (deg C) dans le
    titre et sur stdout. Fermez la fenêtre pour terminer.
    """
    rgb = colorize_temperature(thermal_image.temperature_c, cmap_name=cmap_name)

    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(rgb)
    ax.set_title(
        f"{thermal_image.source_path.name} — cliquez sur un pixel pour lire sa température"
    )

    marker, = ax.plot([], [], "w+", markersize=14, markeredgewidth=2)

    def on_click(event):
        if event.inaxes != ax or event.xdata is None or event.ydata is None:
            return
        x, y = int(round(event.xdata)), int(round(event.ydata))
        try:
            temp = thermal_image.temperature_at(x, y)
        except IndexError:
            return
        marker.set_data([x], [y])
        ax.set_title(f"Pixel ({x}, {y}) — {temp:.2f} °C")
        print(f"Pixel ({x}, {y}) -> {temp:.2f} °C")
        fig.canvas.draw_idle()

    fig.canvas.mpl_connect("button_press_event", on_click)
    plt.colorbar(im, ax=ax, label="Rendu visuel (colorisation, pas la source des températures)")
    plt.tight_layout()
    
    plt.show()